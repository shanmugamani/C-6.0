﻿using TempleDA;

namespace TempleBLL
{
    public class ReadFamilyIDBL : IReadFamilyIDBL
    {
        IReadFamilyID readfamilyid = null;
        public ReadFamilyIDBL()
        {
            readfamilyid = new ReadFamilyID();
        }

        public ReadFamilyIDBL(IReadFamilyID _readfamilyid)
        {
            readfamilyid = _readfamilyid;
        }
        public int GetFamilyID(string aadhar)
        {
            return readfamilyid.GetFamilyIDByMemberID(aadhar);
        }
    }
}
