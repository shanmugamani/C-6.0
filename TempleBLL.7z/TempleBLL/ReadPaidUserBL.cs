﻿using System;
using System.Collections.Generic;
using Temple.Common;
using TempleDA;

namespace TempleBLL
{
    public class ReadPaidUserBL : IReadPaidUserBL
    {

        private IReadPaidUser _objPaiduser = null;

        public ReadPaidUserBL()
        {
            _objPaiduser = new ReadPaidUser();
        }

        public ReadPaidUserBL(IReadPaidUser objPaiduser)
        {
            _objPaiduser = objPaiduser;
        }
        public List<MemberDTO> GetPaidUserDetails(string year)
        {
            int currentselection = year == string.Empty ? Convert.ToInt32(DateTime.Now.Year) : Convert.ToInt32(year);
            List<MemberDTO> users = _objPaiduser.GetPaidUsers(currentselection);
            return users;
        }
    }
}
