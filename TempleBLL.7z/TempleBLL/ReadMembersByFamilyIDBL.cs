﻿using System.Collections.Generic;
using Temple.Common;
using TempleDA;

namespace TempleBLL
{
    public class ReadMembersByFamilyIDBL : IReadMembersByFamilyIDBL
    {
        IReadMembersByFamilyID _readMembersByFamily = null;
        IReadFamilyIDBL _readFamilyId = null;


        public ReadMembersByFamilyIDBL()
        {
            _readMembersByFamily = new ReadMembersByFamilyID();
            _readFamilyId = new ReadFamilyIDBL();
        }
        public ReadMembersByFamilyIDBL(IReadMembersByFamilyID readMembersByFamily)
        {
            _readMembersByFamily = readMembersByFamily;
        }
        public List<MemberDTO> GetMembersByFamilyID(string aadhar)
        {
            List<MemberDTO> members = null;

            int familyid = _readFamilyId.GetFamilyID(aadhar);

            members = _readMembersByFamily.GetMembersByFamilyID(familyid);

            return members ?? new List<MemberDTO>();
        }
    }
}
