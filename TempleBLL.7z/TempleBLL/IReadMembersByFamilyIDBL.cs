﻿using System.Collections.Generic;
using Temple.Common;

namespace TempleBLL
{
    public interface IReadMembersByFamilyIDBL
    {
        List<MemberDTO> GetMembersByFamilyID(string aadhar);
    }
}
