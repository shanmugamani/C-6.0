﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Temple.Common;
using TempleDA;

namespace TempleBLL
{
    public class InsertMemberAndFamilyBL : IInsertMemberAndFamilyBL
    {
        IMemberRegistration objMemberRegister = null;
        IFamilyRegistration objFamilyRegister = null;
        IMapFamilyAndMember objMapFamilyMember = null;
        IGeneratePaymentRecordBL objGeneratePaymentBL = null;
        public InsertMemberAndFamilyBL()
        {
            objMemberRegister = new MemberRegistration();
            objFamilyRegister = new FamilyRegistration();
            objMapFamilyMember = new MapFamilyAndMember();
            objGeneratePaymentBL = new GeneratePaymentRecordBL();
        }

        public InsertMemberAndFamilyBL(IMemberRegistration _objMemberRegister,
            IFamilyRegistration _objFamilyRegister,
            IMapFamilyAndMember _objMapFamilyAndMember,
            IGeneratePaymentRecordBL _objGeneratePaymentBL)
        {
            objMemberRegister = _objMemberRegister;
            objFamilyRegister = _objFamilyRegister;
            objMapFamilyMember = _objMapFamilyAndMember;
            objGeneratePaymentBL = _objGeneratePaymentBL;
        }
        public void ManageMembers(List<MemberDTO> lstMember)
        {
            int amount = 0;
            int familyid = 0;
            string familyname = string.Empty;
            List<int> insertMemberIds = new List<int>();

            lstMember.ForEach(x =>
            {
                x.dob = x.dob.Date;
                x.marriagedate = x.marriagedate.Date;
            });


            //1. Insert Member details in member table
            insertMemberIds = objMemberRegister.InsertMembers(lstMember);

            //2. Create a family in Family table
            var data = lstMember.Select(x => new { name = x.husband, x.aadhar }).FirstOrDefault();
            familyname = data.name + data.aadhar;
            familyid = objFamilyRegister.GenerateFamily(familyname);

            //3. Map Family and Member in FamilyMember Table
            objMapFamilyMember.MapFamilyWithMember(insertMemberIds, familyid);

            //4. Insert payment in PaymentHistory table
            amount = lstMember.Select(x => x.amount).FirstOrDefault().Value;
            objGeneratePaymentBL.CreatePaymentRecord(familyid, insertMemberIds, amount);

        }
    }
}
