﻿using System;
using Temple.Common;
using TempleDA;

namespace TempleBLL
{
    public class UpdateMemberBL : IUpdateMemberBL
    {
        private IUpdateMember _updateMember = null;
        public UpdateMemberBL()
        {
            _updateMember = new UpdateMember();
        }

        public UpdateMemberBL(IUpdateMember updateMember)
        {
            _updateMember = updateMember;
        }        

        public void ModifyMember(MemberDTO member)
        {
            _updateMember.UpdateMemberData(member);
        }
    }
}
