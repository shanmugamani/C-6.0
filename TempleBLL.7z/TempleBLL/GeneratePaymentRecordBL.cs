﻿using System.Collections.Generic;
using TempleDA;

namespace TempleBLL
{
    public class GeneratePaymentRecordBL : IGeneratePaymentRecordBL
    {
        private IGeneratePaymentRecord _GeneratePayment = null;
        public GeneratePaymentRecordBL()
        {
            _GeneratePayment = new GeneratePaymentRecord();
        }

        public GeneratePaymentRecordBL(IGeneratePaymentRecord generatePayment)
        {
            _GeneratePayment = generatePayment;
        }
        public void CreatePaymentRecord(int familyid, List<int> memberids, int amount)
        {
            _GeneratePayment.CreatePaymentRecord(familyid, memberids, amount);
        }
    }
}
