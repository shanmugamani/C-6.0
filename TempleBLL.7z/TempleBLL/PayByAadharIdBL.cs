﻿using System;
using TempleDA;

namespace TempleBLL
{
    public class PayByAadharIdBL : IPayByAadharIdBL
    {
        IPayByAadharId objPay = null;

        public PayByAadharIdBL()
        {
            objPay = new PayByAadharId();
        }

        public PayByAadharIdBL(IPayByAadharId _objPay)
        {
            objPay = _objPay;
        }
        public void PayAnnualTaxToTemple(string aadhar,int variAmount)
        {
            objPay.PayTempleTaxByAadhar(aadhar, variAmount);
        }
    }
}
