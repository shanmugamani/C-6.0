﻿using Temple.Common;

namespace TempleBLL
{
    public interface IUpdateMemberBL
    {
        void ModifyMember(MemberDTO member);
    }
}
