﻿using Temple.Common;
using TempleDA;

namespace TempleBLL
{
    public class ReadMemberByAadharBL : IReadMemberByAadharBL
    {
        IReadMemberByAadhar objReadMember = null;

        public ReadMemberByAadharBL()
        {
            objReadMember = new ReadMemberByAadhar();
        }

        public ReadMemberByAadharBL(IReadMemberByAadhar _objReadMember)
        {
            objReadMember = _objReadMember;
        }
        public MemberDTO GetMemberByAadhar(string aadhar)
        {            
            MemberDTO member = objReadMember.GetMember(aadhar);
            return member;
        }
    }
}
