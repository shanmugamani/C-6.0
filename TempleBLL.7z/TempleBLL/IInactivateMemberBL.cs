﻿namespace TempleBLL
{
    public  interface IInactivateMemberBL
    {
        void DeleteMember(string aadhar);
    }
}
