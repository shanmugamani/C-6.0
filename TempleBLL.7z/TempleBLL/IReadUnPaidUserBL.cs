﻿using System.Collections.Generic;
using Temple.Common;

namespace TempleBLL
{
    public  interface IReadUnPaidUserBL
    {
        List<MemberDTO> GetUnPaidMembers(string year);
    }
}
