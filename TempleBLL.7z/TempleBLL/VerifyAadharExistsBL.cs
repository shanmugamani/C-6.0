﻿#region Namespace(s)
using System.Collections.Generic;
using System.Linq;
using Temple.Common;
using TempleDA;
#endregion

namespace TempleBLL
{
    public class VerifyAadharExistsBL: IVerifyAadharExistsBL
    {

        private IVerifyAadharExists objVerifyAadhar = null;

        #region Constructor(s)
        public VerifyAadharExistsBL()
        {
            objVerifyAadhar = new VerifyAadharExists();
        }

        public VerifyAadharExistsBL(IVerifyAadharExists _objVerifyAadhar)
        {
            objVerifyAadhar = _objVerifyAadhar;
        }
        #endregion

        #region Public Method(s)
        public bool VerifyAadharExistsOrNot(List<MemberDTO> members)
        {
            bool result = false;
            List<string> aadhars = members.Select(x => x.aadhar).ToList();
            foreach (var item in aadhars)
            {
                if (item==string.Empty || item==null)
                {
                    result = true;
                    break;
                }
            }
            if (!result)
            {
                result = objVerifyAadhar.VerifyAadharID(aadhars);
            }
            return result;
        } 
        #endregion
    }
}
