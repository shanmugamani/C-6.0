﻿using TempleDA;

namespace TempleBLL
{
    public class InactivateMemberBL : IInactivateMemberBL
    {
        IInactivateMember _objinactiveMember = null;

        public InactivateMemberBL()
        {
            _objinactiveMember = new InactivateMember();
        }

        public InactivateMemberBL(IInactivateMember objinactiveMember)
        {
            _objinactiveMember = objinactiveMember;
        }
        public void DeleteMember(string aadhar)
        {
            _objinactiveMember.SoftDeleteMember(aadhar);
        }
    }
}
