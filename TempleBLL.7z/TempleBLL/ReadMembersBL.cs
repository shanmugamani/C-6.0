﻿#region Namespaces(s)
using System.Collections.Generic;
using Temple.Common;
using TempleDA; 
#endregion

namespace TempleBLL
{
    public class ReadMembersBL : IReadMembersBL
    {

        private IReadMembers _ReadMembers = null;

        #region Constructor(s)
        public ReadMembersBL()
        {
            _ReadMembers = new ReadMembers();
        }

        public ReadMembersBL(ReadMembers readMembers)
        {
            _ReadMembers = readMembers;
        } 
        #endregion

        public List<MemberDTO> GetMembers()
        {
            List<MemberDTO> members = _ReadMembers.GetMembers();
            return members;
        }
    }
}
