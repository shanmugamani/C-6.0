﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TempleBLL
{
    public class InsertFamilyBL : IInsertFamilyBL
    {
        public int CreateFamily(string name)
        {
            throw new NotImplementedException();
        }
    }
}
