﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Temple.Common;
using TempleDA;

namespace TempleBLL
{
    public class ReadUnPaidUserBL : IReadUnPaidUserBL
    {
        private IReadUnPaidUser _readunpaiduser = null;

        #region constructor(s)
        public ReadUnPaidUserBL()
        {
            _readunpaiduser = new ReadUnPaidUser();
        }

        public ReadUnPaidUserBL(IReadUnPaidUser readunpaiduser)
        {
            _readunpaiduser = readunpaiduser;
        }
        #endregion

        #region Public Method(s)
        public List<MemberDTO> GetUnPaidMembers(string year)
        {
            int recordForTheYear = year == string.Empty ? DateTime.Now.Year : Convert.ToInt32(year);
            List<MemberDTO> members = _readunpaiduser.GetUnPaidUsers(recordForTheYear);
            return members;
        }
        #endregion
    }
}
