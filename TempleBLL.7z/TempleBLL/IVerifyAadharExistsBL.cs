﻿using System.Collections.Generic;
using Temple.Common;

namespace TempleBLL
{
    public interface IVerifyAadharExistsBL
    {
        bool VerifyAadharExistsOrNot(List<MemberDTO> member);
    }
}
