﻿using System.Collections.Generic;

namespace TempleBLL
{
    public interface IGeneratePaymentRecordBL
    {
        void CreatePaymentRecord(int familyid, List<int> memberids, int amount);
    }
}
