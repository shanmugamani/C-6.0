﻿namespace TempleBLL
{
    public interface IPayByAadharIdBL
    {
        void PayAnnualTaxToTemple(string aadhar,int variAmount);
    }
}
