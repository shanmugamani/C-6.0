﻿using System.Collections.Generic;
using Temple.Common;

namespace TempleBLL
{
    public interface IReadPaidUserBL
    {
        List<MemberDTO> GetPaidUserDetails(string year);
    }
}
