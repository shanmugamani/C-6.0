﻿function AadharFocus() {
	EnableSubmitButton();
	$('#errAadhar').css('display', 'none');
}

function EnableSubmitButton() {
	$('#btnSubmit').prop('disabled', false);
}

function DisableSubmitButton() {
	$('#btnSubmit').prop('disabled', true);
}

function Reset() {
	table.rows('.deletable').remove().draw();
	CreateRegistrationTableRow(table);
}

function CreateRegistrationTableRow(table) {
	let counter = 1;
	//table.row.addClass("deletable");
	table.row.add([
		`<input type="text" id="txtName${counter}" placeholder="Enter Name"/>`,
		`<input type="text" name="aadhar" class="aadhar" id="txtAadhar${counter}" placeholder="Enter Aadhar No" onfocus="AadharFocus()" />`,
		`<input type="text" id="txtBirthday${counter}" name="birthday"/>`,
		`<select id="isMarried${counter}" name="isMarried">
						<option value="yes">Yes</option>
						<option value="No" selected>No</option>
					</select>`,
		`<input type="text" name="spousename" id="txtSpouse${counter}" placeholder="Enter spouse Name" />`,
		`<input type="text" name="marriagedate" id="txtMarriage${counter}" />`,
		`<input type="text" name="country" id="txtCountry${counter}" />`,
		`<input type="text" name="address" id="txtAddress${counter}" maxlength="500" />`,
		`<input type="text" name="phone" id="txtPhone${counter}" />`,
		`<td><input type="text" name="amount" id="txtAmount${counter}" value="${@ViewBag.VariAmount
} " disabled/></td>`,
	`<input type="button" value="Remove" id="btnRemove" class="btn btn-primary btn-warning" />`
			]).draw(false);
counter++;
		}