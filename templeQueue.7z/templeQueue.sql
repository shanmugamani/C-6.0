USE [Temple]
GO

/****** Object:  Table [dbo].[Member]    Script Date: 1/1/2020 2:54:05 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Member](
	[MemberId] [int] IDENTITY(1,1) NOT NULL,
	[Husband] [varchar](50) NOT NULL,
	[Spouse] [varchar](50) NULL,
	[DOB] [date] NOT NULL,
	[DOM] [date] NULL,
	[Phone] [varchar](20) NOT NULL,
	[Address] [varchar](250) NOT NULL,
	[CountryLiving] [varchar](25) NOT NULL,
	[IsActive] [bit] NOT NULL,
	[aadhar] [varchar](12) NOT NULL,
	[amount] [int] NULL,
	[PaidOn] [date] NULL,
	[IsMarried] [bit] NULL,
	[SpouseBDay] [date] NULL,
	[Role] [varchar](15) NULL,
 CONSTRAINT [PK_Member] PRIMARY KEY CLUSTERED 
(
	[MemberId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO



CREATE TABLE [dbo].[Family](
	[FamilyID] [int] IDENTITY(1,1) NOT NULL,
	[FamilyName] [varchar](50) NULL,
 CONSTRAINT [PK_Family] PRIMARY KEY CLUSTERED 
(
	[FamilyID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

USE [Temple]
GO

/****** Object:  Table [dbo].[FamilyMemberMapping]    Script Date: 1/1/2020 2:55:14 PM ******/

CREATE TABLE [dbo].[FamilyMemberMapping](
	[MapId] [int] IDENTITY(1,1) NOT NULL,
	[MemberId] [int] NOT NULL,
	[FamilyId] [int] NOT NULL,
 CONSTRAINT [PK_FamilyMemberMapping] PRIMARY KEY CLUSTERED 
(
	[MapId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[FamilyMemberMapping]  WITH CHECK ADD  CONSTRAINT [FK_FamilyMemberMapping_Family] FOREIGN KEY([FamilyId])
REFERENCES [dbo].[Family] ([FamilyID])
GO

ALTER TABLE [dbo].[FamilyMemberMapping] CHECK CONSTRAINT [FK_FamilyMemberMapping_Family]
GO

USE [Temple]
GO

CREATE TABLE [dbo].[PaymentHistory](
	[PaymentID] [smallint] IDENTITY(1,1) NOT NULL,
	[FamilyID] [int] NOT NULL,
	[MemberId] [int] NOT NULL,
	[PaidOn] [date] NOT NULL,
	[Amount] [int] NOT NULL,
 CONSTRAINT [PK_PaymentHistory] PRIMARY KEY CLUSTERED 
(
	[PaymentID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[PaymentHistory]  WITH CHECK ADD  CONSTRAINT [FK_PaymentHistory_Family] FOREIGN KEY([FamilyID])
REFERENCES [dbo].[Family] ([FamilyID])
GO

ALTER TABLE [dbo].[PaymentHistory] CHECK CONSTRAINT [FK_PaymentHistory_Family]
GO

ALTER TABLE [dbo].[PaymentHistory]  WITH CHECK ADD  CONSTRAINT [FK_PaymentHistory_Member] FOREIGN KEY([MemberId])
REFERENCES [dbo].[Member] ([MemberId])
GO

ALTER TABLE [dbo].[PaymentHistory] CHECK CONSTRAINT [FK_PaymentHistory_Member]
GO

