﻿#region Namespace(s)
using System;
using System.Collections.Generic;
using System.Linq;
using Temple.Common; 
#endregion

namespace TempleDA
{
    public  class ReadPaidUser: IReadPaidUser
    {
       public List<MemberDTO> GetPaidUsers(int year)
        {
            List<MemberDTO> paidMembers = new List<MemberDTO>();
            try
            {
                using (TempleEntities ctx = new TempleEntities())
                {

                    paidMembers = (from m in ctx.Members
                                   join map in ctx.FamilyMemberMappings on m.MemberId equals map.MemberId
                                   join f in ctx.Families on map.FamilyId equals f.FamilyID
                                   join p in ctx.PaymentHistories
                                   on m.MemberId equals p.MemberId
                                   where p.PaidOn.Year == year
                                   select new MemberDTO()
                                   {
                                       aadhar = m.aadhar,
                                       address = m.Address,
                                       amount = m.amount.Value,
                                       country = m.CountryLiving,
                                       dob = m.DOB,
                                       husband = m.Husband,
                                       marriagedate = m.DOM.Value,
                                       PaidOn = p.PaidOn,
                                       phone = m.Phone,
                                       spouse = m.Spouse,
                                       familyname = f.FamilyName
                                   }).ToList();

                }
            }
            catch (Exception err)
            {
                throw;
            }

            return paidMembers;
        }
    }
}
