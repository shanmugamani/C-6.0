﻿using System;
using System.Linq;

namespace TempleDA
{
    public class ReadFamilyID : IReadFamilyID
    {
        public int GetFamilyIDByMemberID(string aadhar)
        {
            int familyId = 0;
            try
            {
                using (TempleEntities ctx= new TempleEntities())
                {
                    int memberid = (from m in ctx.Members
                                    join fm in ctx.FamilyMemberMappings on m.MemberId equals fm.MemberId
                                    join f in ctx.Families on fm.FamilyId equals f.FamilyID
                                    where m.aadhar == aadhar
                                    select m.MemberId).FirstOrDefault();

                    familyId = (from f in ctx.FamilyMemberMappings
                                where f.MemberId == memberid
                                select f.FamilyId).FirstOrDefault();
                }
            }
            catch (Exception err)
            {

                throw;
            }
            return familyId;

        }
    }
}
