﻿#region Namespace(s)
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using Temple.Common;
#endregion

namespace TempleDA
{
    public class ReadUnPaidUser : IReadUnPaidUser
    {
        public List<MemberDTO> GetUnPaidUsers(int year)
        {
            List<MemberDTO> unpaidMembers = new List<MemberDTO>();
            List<MemberDTO> unpaidMembersWithFamilyName = new List<MemberDTO>();
            try
            {
                using (TempleEntities ctx = new TempleEntities())
                {

                    unpaidMembers = (from m in ctx.Members
                                     join p in ctx.PaymentHistories
                                     on m.MemberId equals p.MemberId
                                     where p.PaidOn.Year != year
                                     select new MemberDTO()
                                     {
                                         ID = m.MemberId,
                                         aadhar = m.aadhar,
                                         address = m.Address,
                                         amount = m.amount.Value,
                                         country = m.CountryLiving,
                                         dob = m.DOB,
                                         husband = m.Husband,
                                         marriagedate = m.DOM.Value,
                                         PaidOn = p.PaidOn,
                                         phone = m.Phone,
                                         spouse = m.Spouse
                                     }).ToList();


                    var paidmemberIdList = (from m in ctx.Members
                                            join p in ctx.PaymentHistories
                                            on m.MemberId equals p.MemberId
                                            where p.PaidOn.Year == year
                                            select m.MemberId).ToList();

                    unpaidMembersWithFamilyName = (from m in ctx.Members
                                                   join map in ctx.FamilyMemberMappings on m.MemberId equals map.MemberId
                                                   join f in ctx.Families on map.FamilyId equals f.FamilyID
                                                   join p in ctx.PaymentHistories
                                                   on m.MemberId equals p.MemberId
                                                   where p.PaidOn.Year != year
                                                   select new MemberDTO()
                                                   {
                                                       ID = m.MemberId,
                                                       aadhar = m.aadhar,
                                                       address = m.Address,
                                                       amount = m.amount.Value,
                                                       country = m.CountryLiving,
                                                       dob = m.DOB,
                                                       husband = m.Husband,
                                                       marriagedate = m.DOM.Value,
                                                       PaidOn = p.PaidOn,
                                                       phone = m.Phone,
                                                       spouse = m.Spouse,
                                                       familyname = f.FamilyName
                                                   }).ToList();

                    foreach (var item in paidmemberIdList)
                    {
                        var removeMember = unpaidMembersWithFamilyName.Where(x => x.ID == item).Select(x => x).FirstOrDefault();
                        unpaidMembersWithFamilyName.Remove(removeMember);
                    }


                    unpaidMembersWithFamilyName.ForEach(x =>
                    {
                        x.paidDate = x.PaidOn.Value.ToShortDateString();
                    });


                }
            }
            catch (Exception err)
            {

                throw;
            }

            return unpaidMembersWithFamilyName;
        }
    }
}
