﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Temple.Common;

namespace TempleDA
{
    public class UpdateMember : IUpdateMember
    {
        public void UpdateMemberData(MemberDTO member)
        {
            try
            {
                using (TempleEntities ctx=new TempleEntities())
                {
                    Member objMember = (from m in ctx.Members
                                   where m.MemberId == member.ID
                                   select m).FirstOrDefault();

                    objMember.Husband = member.husband;
                    objMember.aadhar = member.aadhar;
                    objMember.Address = member.address;
                    objMember.CountryLiving = member.country;
                    objMember.DOB = member.dob;
                    objMember.DOM = member.marriagedate;
                    objMember.Phone = member.phone;
                    objMember.Spouse = member.spouse;
                    objMember.Role = member.Role;
                    ctx.SaveChanges();
                }
            }
            catch (Exception err)
            {

                throw;
            }
        }
    }
}
