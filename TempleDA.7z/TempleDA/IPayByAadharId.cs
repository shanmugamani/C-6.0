﻿namespace TempleDA
{
    public interface IPayByAadharId
    {
        void PayTempleTaxByAadhar(string aadhar, int variAmount);
    }
}
