﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace TempleDA
{
    public class VerifyAadharExists : IVerifyAadharExists
    {
        public bool VerifyAadharID(List<string> lstaadhar)
        {
            List<string> aadhars = new List<string>();
            int countExists = 0;
            bool alreadyExists = false;

            try
            {
                using (TempleEntities ctx = new TempleEntities())
                {
                    aadhars = (from m in ctx.Members
                               select m.aadhar).ToList();

                    for (int i = 0; i < lstaadhar.Count; i++)
                    {
                        for (int j = 0; j < aadhars.Count; j++)
                        {
                            if (lstaadhar[i] == aadhars[j])
                            {
                                countExists += 1;
                                break;
                            }
                        }
                    }

                }
            }
            catch (Exception err)
            {
                throw;
            }

            if (countExists>0)
            {
                alreadyExists = true;
            }
           
            return alreadyExists;
        }
    }
}
