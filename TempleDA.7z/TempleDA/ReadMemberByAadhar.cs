﻿using System;
using System.Linq;
using Temple.Common;

namespace TempleDA
{
    public class ReadMemberByAadhar : IReadMemberByAadhar
    {
        public MemberDTO GetMember(string aadhar)
        {
            MemberDTO objMember = new MemberDTO();

            try
            {
                using (TempleEntities ctx = new TempleEntities())
                {
                    objMember = (from m in ctx.Members
                                 where m.aadhar == aadhar                                 
                                 select new MemberDTO {
                                     ID = m.MemberId,
                                     husband = m.Husband,
                                     spouse = m.Spouse,
                                     dob = m.DOB,
                                     marriagedate = m.DOM.Value,
                                     country = m.CountryLiving,
                                     phone = m.Phone,
                                     address = m.Address,
                                     aadhar = m.aadhar,
                                     isMarried = m.IsMarried.Value == true ? "Yes" : "No",
                                     SpouseBDay = m.SpouseBDay.Value,
                                     Role = m.Role
                                 }).FirstOrDefault();
                }
            }
            catch (Exception err)
            {

                throw;
            }
            return objMember;
        }
    }
}
