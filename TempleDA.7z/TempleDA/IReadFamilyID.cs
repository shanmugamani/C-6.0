﻿namespace TempleDA
{
    public interface IReadFamilyID
    {
        int GetFamilyIDByMemberID(string aadhar);
    }
}