﻿using System;
using System.Collections.Generic;
using System.Linq;
using Temple.Common;

namespace TempleDA
{
    public class ReadMembers : IReadMembers
    {
        public List<MemberDTO> GetMembers()
        {
            MemberDTO objMember = new MemberDTO();
             List<MemberDTO> members = new List<MemberDTO>();

            try
            {
                using (TempleEntities ctx = new TempleEntities())
                {
                    members = (from m in ctx.Members
                                               where m.IsActive == true 
                                               && m.IsMarried == true
                                               select new MemberDTO()
                                               {
                                                   husband = m.Husband,
                                                   spouse = m.Spouse,
                                                   dob = m.DOB,
                                                   marriagedate = m.DOM.Value,
                                                   country = m.CountryLiving,
                                                   phone = m.Phone,
                                                   address = m.Address,
                                                   aadhar = m.aadhar,
                                                   isMarried = m.IsMarried.Value == true ? "Yes" : "No",
                                                   SpouseBDay = m.SpouseBDay.Value
                                               }).ToList();
                }
            }
            catch (Exception err)
            {

                throw;
            }

            return members;
        }
    }
}
