﻿using System;
using System.Linq;

namespace TempleDA
{
    public class InactivateMember : IInactivateMember
    {
        public void SoftDeleteMember(string aadhar)
        {
            try
            {
                using (TempleEntities ctx = new TempleEntities())
                {
                    Member member = (from m in ctx.Members
                                     where m.aadhar == aadhar
                                     select m).FirstOrDefault();

                    member.IsActive = false;
                    ctx.SaveChanges();
                }
            }
            catch (Exception err)
            {

                throw;
            }
        }
    }
}
