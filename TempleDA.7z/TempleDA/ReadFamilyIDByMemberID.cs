﻿using System;
using System.Linq;

namespace TempleDA
{
    public class ReadFamilyIDByMemberID : IReadFamilyIDByMemberID
    {
        public int GetFamilyID(int memberId)
        {
            int familyId = 0;

            try
            {
                using (TempleEntities ctx = new TempleEntities())
                {
                    familyId = (from fid in ctx.FamilyMemberMappings
                                join m in ctx.Members on fid.MemberId equals m.MemberId
                                where fid.MemberId == memberId
                                select fid.FamilyId).FirstOrDefault();
                }
            }
            catch (Exception err)
            {
                 
                throw;
            }

            return familyId;
        }
    }
}
