﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Temple.Common;

namespace TempleDA
{
   public interface IMemberRegistration
    {
        List<int> InsertMembers(List<MemberDTO> members);
    }
}
