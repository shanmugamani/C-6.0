﻿namespace TempleDA
{
  public  interface IInactivateMember
    {
        void SoftDeleteMember(string aadhar);
    }
}
