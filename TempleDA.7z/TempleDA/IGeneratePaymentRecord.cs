﻿using System.Collections.Generic;

namespace TempleDA
{
    public  interface IGeneratePaymentRecord
    {
        void CreatePaymentRecord(int familyid, List<int> memberids, int amount);
    }
}
