﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Temple.Common;

namespace TempleDA
{
    public class PayByAadharId : IPayByAadharId
    {
        IReadMemberByAadhar objReadMember = null;        
        IReadFamilyIDByMemberID objReadFamilyId = null;
        IGeneratePaymentRecord objPayment = null;

        public PayByAadharId()
        {
            objReadMember = new ReadMemberByAadhar();            
            objReadFamilyId = new ReadFamilyIDByMemberID();
            objPayment = new GeneratePaymentRecord();
        }

        public PayByAadharId(IReadMemberByAadhar _objReadMember, 
                             IReadFamilyIDByMemberID _objReadFamilyId,
                             IGeneratePaymentRecord _objPayment)
        {
            objReadMember = _objReadMember;
            objReadFamilyId = _objReadFamilyId;
            objPayment = _objPayment;
        }

        public void PayTempleTaxByAadhar(string aadhar,int variAmount)
        {
            MemberDTO member = objReadMember.GetMember(aadhar);
            int memberId = member.ID;
            List<int> members = new List<int> { memberId };

            int familyId = objReadFamilyId.GetFamilyID(memberId);

            objPayment.CreatePaymentRecord(familyId, members, variAmount);
        }
    }
}
