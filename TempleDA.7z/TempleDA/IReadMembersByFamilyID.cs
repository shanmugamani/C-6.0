﻿using System.Collections.Generic;
using Temple.Common;

namespace TempleDA
{
    public interface IReadMembersByFamilyID
    {
        List<MemberDTO> GetMembersByFamilyID(int familyId);
    }
}