﻿using Temple.Common;

namespace TempleDA
{
    public interface IUpdateMember
    {
        void UpdateMemberData(MemberDTO member);
    }
}
