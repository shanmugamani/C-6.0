﻿#region Namespace(s)
using System;
using System.Linq; 
#endregion

namespace TempleDA
{
    /// <summary>
    /// This class is used to insert data in Family Table
    /// </summary>
    public class FamilyRegistration : IFamilyRegistration
    {
        #region Public Method(s)
        public int GenerateFamily(string name)
        {
            int insertedFamilyId = 0;
            try
            {
                using (TempleEntities ctx = new TempleEntities())
                {
                    string familyname = name + "123";
                    Family family = new Family()
                    {
                        FamilyName = familyname
                    };
                    ctx.Families.Add(family);
                    ctx.SaveChanges();
                    insertedFamilyId = ReturnLastFamilyId();
                }
            }
            catch (Exception err)
            {

                throw;
            }
            return insertedFamilyId;
        }
        #endregion

        #region Private Method(s)
        private int ReturnLastFamilyId()
        {
            int familyId = 0;
            try
            {
                using (TempleEntities ctx = new TempleEntities())
                {
                    familyId = (from f in ctx.Families
                                orderby f.FamilyID descending
                                select f.FamilyID).Take(1).FirstOrDefault();
                }
            }
            catch (Exception err)
            {

                throw;
            }

            return familyId;
        } 
        #endregion
    }
}
