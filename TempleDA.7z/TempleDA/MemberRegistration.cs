﻿#region Namespace(s)
using System;
using System.Collections.Generic;
using System.Linq;
using Temple.Common;
#endregion

namespace TempleDA
{
    /// <summary>
    /// This class is used to insert member detail in Member table
    /// </summary>
    public class MemberRegistration : IMemberRegistration
    {
        #region Public Method(s)
        public List<int> InsertMembers(List<MemberDTO> members)
        {
            List<int> lstMemberId = new List<int>();

            try
            {
                using (TempleEntities ctx = new TempleEntities())
                {
                    foreach (var item in members)
                    {
                        Member objMember = new Member()
                        {
                            Husband = item.husband,
                            Spouse = item.spouse,
                            DOB = item.dob,
                            DOM = item.marriagedate,
                            SpouseBDay = item.SpouseBDay,
                            IsMarried = item.isMarried == "Yes" ? true : false,
                            Phone = item.phone,
                            Address = item.address,
                            CountryLiving = item.country,
                            IsActive = true,
                            aadhar = item.aadhar,
                            amount = item.amount,
                            PaidOn = DateTime.Now.Date,
                            Role = item.Role                            
                        };

                        ctx.Members.Add(objMember);
                        ctx.SaveChanges();
                        int lastInsertedId = InsertedMemberID();
                        lstMemberId.Add(lastInsertedId);
                    }

                }
            }
            catch (Exception err)
            {

                throw;
            }

            return lstMemberId;
        }
        #endregion

        #region Private Method(s)
        private int InsertedMemberID()
        {
            int lastInsertedId = 0;
            try
            {
                using (TempleEntities ctx = new TempleEntities())
                {
                    lastInsertedId = (from m in ctx.Members
                                      where m.IsMarried == true
                                      orderby m.MemberId descending
                                      select m.MemberId).FirstOrDefault();
                }
            }
            catch (Exception err)
            {

                throw;
            }

            return lastInsertedId;
        }
        #endregion
    }
}
