﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Temple.Common;

namespace TempleDA
{
    public class ReadMembersByFamilyID : IReadMembersByFamilyID
    {
        public List<MemberDTO> GetMembersByFamilyID(int familyId)
        {
            List<MemberDTO> members = null;

            try
            {
                using (TempleEntities ctx = new TempleEntities())
                {
                    members = (from m in ctx.Members
                               join fm in ctx.FamilyMemberMappings
                               on m.MemberId equals fm.MemberId
                               join f in ctx.Families on
                               fm.FamilyId equals f.FamilyID
                               where f.FamilyID == familyId
                               select new MemberDTO()
                               {
                                   aadhar = m.aadhar,
                                   country = m.CountryLiving,
                                   dob = m.DOB,
                                   marriagedate = m.DOM.Value,
                                   address = m.Address,
                                   familyname = f.FamilyName,
                                   husband = m.Husband,
                                   ID = m.MemberId,
                                   phone = m.Phone,
                                   spouse = m.Spouse,
                                   Role = m.Role
                               }).ToList();
                }

            }
            catch (Exception err)
            {

                throw;
            }

            return members;
        }
    }
}
