﻿using System.Collections.Generic;
using Temple.Common;

namespace TempleDA
{
    public  interface IReadUnPaidUser
    {
        List<MemberDTO> GetUnPaidUsers(int year);
    }
}
