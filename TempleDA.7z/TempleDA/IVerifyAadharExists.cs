﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace TempleDA
{
  public  interface IVerifyAadharExists
    {
        bool VerifyAadharID(List<string> aadhars);
    }
}
