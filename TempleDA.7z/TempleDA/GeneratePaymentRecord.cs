﻿using System;
using System.Collections.Generic;

namespace TempleDA
{
    public class GeneratePaymentRecord : IGeneratePaymentRecord
    {
        public void CreatePaymentRecord(int familyid, List<int> memberids, int amount)
        {
            try
            {
                using (TempleEntities ctx = new TempleEntities())
                {
                    foreach (var item in memberids)
                    {
                        PaymentHistory history = new PaymentHistory()
                        {
                            FamilyID = familyid,
                            MemberId = item,
                            Amount = amount,
                            PaidOn = DateTime.Now.Date
                        };

                        ctx.PaymentHistories.Add(history);
                        ctx.SaveChanges();
                    }
                }
            }
            catch (Exception err)
            {

                throw;
            }
        }
    }
}
