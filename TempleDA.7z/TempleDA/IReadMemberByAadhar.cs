﻿using Temple.Common;

namespace TempleDA
{
    public  interface IReadMemberByAadhar
    {
        MemberDTO GetMember(string aadhar);
    }
}
