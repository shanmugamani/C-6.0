﻿#region Namespace(s)
using System;
using System.Collections.Generic;
#endregion

namespace TempleDA
{
    /// <summary>
    /// This class is used to map family and member data in FamilyMemberMapping table
    /// </summary>
    public class MapFamilyAndMember : IMapFamilyAndMember
    {
        public void MapFamilyWithMember(List<int> lstmemberid, int familyid)
        {
            try
            {
                using (TempleEntities ctx = new TempleEntities())
                {
                    foreach (var item in lstmemberid)
                    {
                        FamilyMemberMapping mapper = new FamilyMemberMapping()
                        {
                            FamilyId = familyid,
                            MemberId = item
                        };

                        ctx.FamilyMemberMappings.Add(mapper);
                        ctx.SaveChanges();
                    }                   
                }
            }
            catch (Exception err)
            {
                throw;
            }
        }
    }
}
