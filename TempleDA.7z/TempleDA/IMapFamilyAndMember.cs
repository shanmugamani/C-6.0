﻿using System.Collections.Generic;

namespace TempleDA
{
    public interface IMapFamilyAndMember
    {
        void MapFamilyWithMember(List<int> lstmemberid,int familyid);
    }
}
