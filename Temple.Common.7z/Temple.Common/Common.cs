﻿namespace Temple.Common
{
    public class Common
    {
        public const int amount = 110;
    }
}
