﻿using System;

namespace Temple.Common
{
    public class MemberDTO
    {
        public int ID { get; set; }
        public string Role { get; set; }
        public string husband { get; set; }

        public string aadhar { get; set; }
        public DateTime dob { get; set; }
        public string isMarried { get; set; }
        public string spouse { get; set; }
        public DateTime? SpouseBDay { get; set; }
        public DateTime marriagedate { get; set; }
        public string country { get; set; }
        public string address { get; set; }
        public string phone { get; set; }
        public int? amount { get; set; }
        public DateTime? PaidOn { get; set; }

        public string paidDate { get; set; }

        public string familyname { get; set; }
    }
}
